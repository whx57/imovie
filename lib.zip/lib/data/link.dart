final Map getlink = {
  "9kantv": "http://www.9kantv.com/",
  "美剧": "https://www.akmeiju.com/",
  "韩剧": "https://www.ihanju.com/",
  "日剧": "https://www.riju5.com/",
  "biliibili": "https://www.bilibili.com/",
  "电影资源下载": "https://www.ygdy8.com/index.html",
  "泰剧": "https://www.taijuwang.com/",
  // "1":"2"
  "人人影视": "https://www.yyetss.cc/",
  "影视解析1": "https://www.itdy.com.cn/",
  "大白影视": "http://dbys.cc/",
  "影视解析2": "http://vip.nxsino.com/",
  "影视解析3": "http://www.fyystv.com/",
  "影视解析4": "http://tv.hzwdd.cn/",
  "影视解析5": "http://www.czjx8.com/",
  "影视解析6": "http://www.gddyu.com/",
  "影视解析7": "https://v.ctrlqq.com/",
};
