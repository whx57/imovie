// import 'imageloader/network_image.dart' as network;
//
// Widget getNetworkImage() {
//   return Container(
//     color: Colors.blue,
//     width: 200,
//     height: 200,
//     child: Image(image: network.NetworkImage("https://flutter.dev/images/flutter-mono-81x100.png")),
//   );
// }
