// import 'package:flutter/material.dart';
//
// class Detail extends StatelessWidget {
//   const Detail({Key key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('test'),
//
//       ),
//       body: Center(
//         child: Image(
//           image: NetworkImage(
//             'https://img2.doubanio.com/view/photo/s_ratio_poster/public/p1968975252.webp'
//           ),
//         ),
//       ),
//     );
//   }
// }
